function Footer() {
  return(
    <section className="footer">
      <p className="footer__copyright">&copy; <span id="currentYear"></span> Around The U.S.</p>
    </section>
  );
}

export default Footer;